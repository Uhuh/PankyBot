export const GUILD_NAME: string = process.env.GUILD_NAME || ""
export const PREFIX: string = process.env.PREFIX || "!"
export const TOKEN: string = process.env.TOKEN || ""
export const ROLE_CHANNEL: string = process.env.ROLE_CHANNEL || "493537813044789248"