import { Message, Channel, GuildMember } from 'discord.js'
import Bowsette from '../src/bot';

const roles: Map<string, string> = new Map([['twist', '493536445710073893'], ['chocolate', '493536349064921099'], ['split', '493557274460028928'], ['vanilla', '493536643639410708'], ['neopolitan', '493536796349693967']])

export default (client: Bowsette, message: Message) => {
  const channel: Channel | undefined = message.channel
  const member: GuildMember = message.member
  const words: string[] = message.content.split(' ')
  let addedRole: boolean = false
  
  if (channel.id === client.config.ROLE_CHANNEL) {
    message.delete()
    for (const i of words) {
      if(member.roles.find(val => val.name === i)) {
        return
      }
    }
    for (const i of words) {
      if (roles.has(i.toLowerCase())) {
        member.addRole(roles.get(i.toLowerCase())!)
        addedRole = true
        break;
      }
    }
    for (const [k, role] of member.roles) {
      if (roles.has(role.name.toLowerCase()) && addedRole) {
        member.removeRole(roles.get(role.name.toLowerCase())!)
        return
      }
    }
  }
}